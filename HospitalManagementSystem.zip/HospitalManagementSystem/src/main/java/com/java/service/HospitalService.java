package com.java.service;
import com.java.dao.*;
import com.java.exceptions.*;
import com.java.entity.*;
import java.util.List;
import java.util.Scanner;

public class HospitalService {
    private Scanner scanner;
    private HospitalDao hdao;

    public HospitalService() {
        scanner = new Scanner(System.in);
        hdao = new HospitalDao();
    }

    public void getAppointmentById() {
        System.out.println("Enter appointment id: ");
        int appointmentId = scanner.nextInt();
        Appointment appointment = hdao.getAppointmentById(appointmentId);
        if (appointment != null) {
            System.out.println(appointment);
        } else {
            System.out.println("Appointment not found.");
        }
    }

    public void getAppointmentsForPatient() {
        try {
            System.out.println("Enter patient id: ");
            int patientId = scanner.nextInt();
            List<Appointment> appointments = hdao.getAppointmentsForPatient(patientId);
        } catch (PatientNumberNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public void getAppointmentsForDoctor() {
        System.out.println("Enter doctor id: ");
        int doctorId = scanner.nextInt();
        List<Appointment> appointments = hdao.getAppointmentsForDoctor(doctorId);
    }

    public void scheduleAppointment() {
        Appointment appointment = new Appointment();
        System.out.println("Enter appointment id: ");
        appointment.setAppointmentId(scanner.nextInt());
        System.out.println("Enter patient id: ");
        appointment.setPatientId(scanner.nextInt());
        System.out.println("Enter doctor id: ");
        appointment.setDoctorId(scanner.nextInt());
        System.out.println("Enter appointment date: ");
        scanner.nextLine(); 
        appointment.setAppointmentDate(scanner.nextLine());
        System.out.println("Enter description: ");
        appointment.setDescription(scanner.nextLine());
        hdao.addAppointment(appointment);
    }
    
    public void updateAppointment() {
        System.out.println("Enter appointment date: ");
        String appointmentDate = scanner.nextLine();
        System.out.println("Enter appointment id: ");
        int appointmentId = scanner.nextInt();
        hdao.updateAppointmentDate(appointmentId, appointmentDate);
    }

    public void cancelAppointment() {
        System.out.println("Enter appointment id: ");
        int appointmentId = scanner.nextInt();
        hdao.cancelAppointment(appointmentId);
    }
    
}