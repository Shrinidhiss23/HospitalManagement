package com.java.dao;
import com.java.entity.*;
import com.java.util.DataConnect;

import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.java.exceptions.*;

public class HospitalDao {
    private Connection con;
    private PreparedStatement stat;

    public HospitalDao() {
        con = DataConnect.getConnect();
    }

    public void addAppointment(Appointment appointment) {
        try {
            stat = con.prepareStatement("INSERT INTO appointment VALUES (?, ?, ?, ?, ?)");
            stat.setInt(1, appointment.getAppointmentId());
            stat.setInt(2, appointment.getPatientId());
            stat.setInt(3, appointment.getDoctorId());
            stat.setString(4, appointment.getAppointmentDate());
            stat.setString(5, appointment.getDescription());
            stat.executeUpdate();
            System.out.println("Appointment scheduled");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cancelAppointment(int appointmentId) {
        try {
            stat = con.prepareStatement("DELETE FROM appointment WHERE appointmentId = ?");
            stat.setInt(1, appointmentId);
            int rowsDeleted = stat.executeUpdate();
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void updateAppointmentDate(int appointmentId, String newAppointmentDate) {
        try {
            stat = con.prepareStatement("UPDATE appointment SET appointmentDate = ? WHERE appointmentId = ?");
            stat.setString(1, newAppointmentDate);
            stat.setInt(2, appointmentId);
            int rowsUpdated = stat.executeUpdate();
       
        } catch (Exception e) {
        	System.out.println(e);
        }
    }

    public Appointment getAppointmentById(int appointmentId) {
        try {
            stat = con.prepareStatement("SELECT * FROM appointment WHERE appointmentId = ?");
            stat.setInt(1, appointmentId);
            ResultSet rs = stat.executeQuery();
            if (rs.next()) {
                return new Appointment(rs.getInt(1), rs.getInt(2),
                        rs.getInt(3), rs.getString(4), rs.getString(5));
            }
        } catch (Exception e) {
        	System.out.println(e);
        }
        return null;
    }

    public List<Appointment> getAppointmentsForPatient(int patientId) throws PatientNumberNotFoundException {
        try {
            stat = con.prepareStatement("SELECT * FROM appointment WHERE patientId = ?");
            stat.setInt(1, patientId);
            ResultSet rs = stat.executeQuery();
            List<Appointment> appointments = new ArrayList<>();
            boolean found = false;
            while (rs.next()) {
                appointments.add(new Appointment(rs.getInt(1), rs.getInt(2),
                        rs.getInt(3), rs.getString(4), rs.getString(5)));
                found = true;
            }
            if (!found) {
                throw new PatientNumberNotFoundException("Appointments for patient with id " + patientId + " not found");
            }
            return appointments;
        } catch (Exception e) {
        	System.out.println(e);
            return null;
        }
    }

    public List<Appointment> getAppointmentsForDoctor(int doctorId) {
        try {
            stat = con.prepareStatement("SELECT * FROM appointment WHERE doctorId = ?");
            stat.setInt(1, doctorId);
            ResultSet rs = stat.executeQuery();
            List<Appointment> appointments = new ArrayList<>();
            while (rs.next()) {
                appointments.add(new Appointment(rs.getInt(1), rs.getInt(2),
                        rs.getInt(3), rs.getString(4), rs.getString(5)));
            }
            return appointments;
        } catch (Exception e) {
        	System.out.println(e);
            return null;
        }
    }
}

