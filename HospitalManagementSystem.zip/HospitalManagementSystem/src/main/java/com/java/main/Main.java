package com.java.main;
import com.java.service.*;
import java.util.*;
public class Main {
	public static void main(String [] args) {
		HospitalService hs = new HospitalService();
		Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("1. get appointment by id");
            System.out.println("2. get appointment for patient");
            System.out.println("3. get appointment for doctor");
            System.out.println("4. schedule appointment");
            System.out.println("5. update appointment");
            System.out.println("6. cancel appointment");
            System.out.println("Enter your choice");

            int choice = sc.nextInt();
            if(choice==1) {
            	hs.getAppointmentById();
            }
            else if(choice==2) {
            	hs.getAppointmentsForPatient();
            }
            else if(choice==3) {
            	hs.getAppointmentsForDoctor();
            }
            else if(choice==4) {
            	hs.scheduleAppointment();
            }
            else if(choice==5) {
            	hs.updateAppointment();
            }
            else if(choice==6) {
            	hs.cancelAppointment();
            }
            else {
            	break;
            }
        }

		sc.close();
	}
}